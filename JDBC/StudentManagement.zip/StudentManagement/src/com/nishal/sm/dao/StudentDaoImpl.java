package com.nishal.sm.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nishal.sm.dto.Student;
import com.nishal.sm.util.DbUtil;

public class StudentDaoImpl implements StudentDao {

	PreparedStatement ps = null;

	@Override
	public void save(Student student) {

		String sql = "INSERT INTO students(name, address, roll) VaLUES (?,?,?)";

		try {
			ps = DbUtil.getConnection().prepareStatement(sql);
			ps.setString(1, student.getName());
			ps.setString(2, student.getAddress());
			ps.setInt(3, student.getRoll());

			ps.executeUpdate();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void update(Student student) {
		String sql = "UPDATE students SET name = ?, address = ?, roll = ? where id = ?";

		try {
			ps = DbUtil.getConnection().prepareStatement(sql);
			ps.setString(1, student.getName());
			ps.setString(2, student.getAddress());
			ps.setInt(3, student.getRoll());
			ps.setInt(4, student.getId());
			ps.executeUpdate();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public List<Student> all() {
		List<Student> studentList = new ArrayList<>();
		
		String sql = "SELECT * FROM students";
		
		try {
			ps = DbUtil.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Student student = new Student();
				student.setName(rs.getString("name"));
				student.setAddress(rs.getString("address"));
				student.setRoll(rs.getInt("roll"));
				student.setId(rs.getInt("id"));
				
				studentList.add(student);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return studentList;
	}

	@Override
	public void delete(int id) {
		String sql = "DELETE from students where id = ?";
		
		try {
			ps = DbUtil.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Student get(int id) {
		Student student = new Student();
		String sql = "SELECT * from students where id=?";

		try {
			ps = DbUtil.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				student.setId(rs.getInt("id"));
				student.setName(rs.getString("name"));
				student.setAddress(rs.getString("address"));
				student.setRoll(rs.getInt("roll"));

			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return student;

	}

}
