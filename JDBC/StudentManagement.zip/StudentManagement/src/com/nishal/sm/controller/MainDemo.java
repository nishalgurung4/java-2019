package com.nishal.sm.controller;

import java.util.List;

import com.nishal.sm.dto.Student;
import com.nishal.sm.service.StudentService;
import com.nishal.sm.service.StudentServiceImpl;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainDemo mainDemo = new MainDemo();

//		mainDemo.saveStudent();
		mainDemo.updateStudent();
		mainDemo.getStudent();
		
//		mainDemo.deleteStudent();
		
		mainDemo.listStudents();

	}

	private void saveStudent() {
		StudentService studentService = new StudentServiceImpl();

		Student student = new Student();
		student.setName("Rohit");
		student.setAddress("Pokhara");
		student.setRoll(3);

		studentService.save(student);
	}

	private void updateStudent() 
	{
		
		StudentService studentService = new StudentServiceImpl();
		Student student = studentService.get(1);
		student.setAddress("Bagar");
		
		studentService.update(student);

	}
	
	private void deleteStudent()
	{
		StudentService studentService = new StudentServiceImpl();
		
		studentService.delete(3);
	}

	private void getStudent() {
		StudentService studentService = new StudentServiceImpl();

		Student student = studentService.get(1);

		System.out.println("ID = " + student.getId());
		System.out.println("Name = " + student.getName());
		System.out.println("Address =" + student.getAddress());
		System.out.println("Roll = " + student.getRoll());
		System.out.println("============================");

	}
	
	private void listStudents()
	{
		StudentService studentService = new StudentServiceImpl();
		List<Student> studentLists = studentService.all();
		
		for(Student student : studentLists)
		{
			System.out.println("ID = " + student.getId());
			System.out.println("Name = " + student.getName());
			System.out.println("Address = " + student.getAddress());
			System.out.println("Roll = " + student.getRoll());
			System.out.println("============================");
		}
	}

}
