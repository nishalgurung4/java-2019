package com.nishal.sm.service;

import java.util.List;

import com.nishal.sm.dao.StudentDao;
import com.nishal.sm.dao.StudentDaoImpl;
import com.nishal.sm.dto.Student;

public class StudentServiceImpl implements StudentService {
	
	StudentDao studentDao = new StudentDaoImpl();

	@Override
	public void save(Student student) {
		//business logic
		
		studentDao.save(student);
	}

	@Override
	public void update(Student student) {
		
		studentDao.update(student);

	}

	@Override
	public List<Student> all() {
		return studentDao.all();
	}

	@Override
	public void delete(int id) {
		studentDao.delete(id);
	}

	@Override
	public Student get(int id) {
		//extra logic
		
		return studentDao.get(id);
	}

}
