package com.nishal.sm.service;

import java.util.List;

import com.nishal.sm.dto.Student;

public interface StudentService {
	public void save(Student student);

	public void update(Student student);

	public List<Student> all();

	public void delete(int id);

	public Student get(int id);
}
